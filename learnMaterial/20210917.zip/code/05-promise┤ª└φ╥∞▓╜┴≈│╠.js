let p1 = new Promise((resolve, reject) => {
  console.log(1)
  resolve('ok') 
  // console.log('2')
  setTimeout(() => { //! 宏任务1 1000ms
    // resolve('ok') //? 只要执行了这行代码,p1 的状态就明确了,所以 p1.then的回调就添加微
    console.log('2')
  }, 1000)
})
// 此时 p1 的状态是什么 pending 
//! then 是一个异步微任务操作,但是它是否被放入到队列中取决于前面 promise 的状态
//! 此处的状态,不考虑 pending ,因此我们需要的是一个明确的状态( 成功,失败 )
//! 如果Promise 的状态明确,它后面的 then 当中的回调会立即被添加的异步的任务队列当中 
p1.then((ret) => { //! 微任务 1
  console.log('success--->', ret)
}, (reason) => {
  console.log('failed--->', reason)
})
console.log(3)
// 1,3, ok, 2

/**
 * 01 new Promise 接收一个 executor 函数,且这个函数是立即执行的,因此 1 最先输出
 * 02 遇到了 setTimeout 操作,这个也是同步的,所以此时会立即往异步宏任务队列当中添加一个宏任务1
 * 03 代码继续自上向下执行,遇到了 p1.then() ,由于此时的p1状态不明确,所以 then 里的回调并没有被立即添加至队列当中(可以认为有一个地方临时保存了这个任务)
 * 04 代码继续向下执行,遇到了 3 ,同步输出 3  
 * 05 3 被输出之后意味着最外面的同步执行完了,此时就去找异步任务,发现有一个宏任务1可以执行.....
 */