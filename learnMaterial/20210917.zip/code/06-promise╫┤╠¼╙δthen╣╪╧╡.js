let p1 = new Promise((resolve, reject) => {
  resolve('ok')
})

let p2 = p1.then((result) => {
  console.log('success-->', result)
  // return 10
  // console.log(a)
  return Promise.reject('000000')
}, (reason) => {
  console.log('failed-->', reason)
  return 20
})

console.log(p2)

p2.then((result) => {
  console.log('success-->', result)
}, (reason) => {
  console.log('failed-->', reason)
})