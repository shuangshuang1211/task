const p1 = new Promise((resolve, reject) => {
  // console.log(1111)
  // console.log(222)
  // resolve('111')
  // reject('222')
  console.log(aaa)
})

console.log(p1)

//! p1 的身上有哪些方法可以去用( 面向对象的思想 )
//! 如果我想要改变一个promise实例的状太,有哪些方法
