setTimeout(() => {
  console.log(1)
}, 0)

console.log(2)
// while (true) { } //! 此时死循环会将主线程一直占用，所以后续代码不执行
throw new Error('手动抛出异常') //! 如果遇到了异常,在这个异常出现之前被添加的异步任务还会执行,后面的就不会执行了
// console.log(a)

console.log(3)

setTimeout(() => {
  console.log(4)
}, 10)

console.log(5)
