/* async function foo() {
  return 100
}

const p1 = foo()

console.log(foo()) */

function abc() {
  console.log(11111)
  return 100
}

async function foo() {
  await abc()
  console.log('哈')
}

const p1 = foo()
console.log(p1)