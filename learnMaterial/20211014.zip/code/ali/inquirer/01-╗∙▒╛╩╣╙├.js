const inquirer = require('inquirer')

//? 定义问题（按照它的格式定义）
const queList = [
  {
    type: 'input',
    name: 'username', //? 它很重要
    message: '用户名',
    validate(an) {
      if (!an) {
        return '当前为必填项'
      } else {
        return true
      }
    }
  }
]

//? 使用inquirer 来处理问题
inquirer.prompt(queList).then((an) => {
  console.log(an)
})
