const inquirer = require('inquirer')

//? 定义问题（按照它的格式定义）
const queList = [
  {
    type: 'confirm',
    name: 'isLoad',
    message: '是否执行下载'
  },
  {
    type: 'list',
    name: 'method',
    message: '选择下载方式',
    choices: ['npm', 'yarn', 'cnpm'],
    when(preAn) {
      return preAn.isLoad
    }
  }
]

//? 使用inquirer 来处理问题
inquirer.prompt(queList).then((an) => {
  console.log(an)
})
