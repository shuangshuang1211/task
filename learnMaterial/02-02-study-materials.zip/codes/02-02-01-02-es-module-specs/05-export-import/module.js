var foo = 'hello'
var bar = 'world'

export { foo, bar }
