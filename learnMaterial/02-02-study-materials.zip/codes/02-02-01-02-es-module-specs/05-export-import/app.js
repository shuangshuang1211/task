// export { foo, bar } from './module.js'

// console.log(foo, bar)

import { Button, Avatar } from './components/index.js'

console.log(Button)
console.log(Avatar)
