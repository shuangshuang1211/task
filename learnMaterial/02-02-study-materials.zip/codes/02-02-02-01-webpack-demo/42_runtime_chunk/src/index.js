import(/*webpackChunkName: 'title' */'./title')

console.log('index.js代码')