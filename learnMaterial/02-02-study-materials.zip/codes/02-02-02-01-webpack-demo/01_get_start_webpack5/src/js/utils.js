const sum = (m, n) => {
  return m + n
}

const square = (m) => {
  return m * m
}

export { sum, square }
