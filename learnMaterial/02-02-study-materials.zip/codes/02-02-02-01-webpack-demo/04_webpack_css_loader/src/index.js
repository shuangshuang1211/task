import { sum, square } from './js/utils.js'
const getInfo = require('./js/api.js')

import './js/login'

console.log(sum(10, 20))
console.log(square(10))
console.log(getInfo())

// 01 为什么需要loader 02loader是什么 03css-loader
