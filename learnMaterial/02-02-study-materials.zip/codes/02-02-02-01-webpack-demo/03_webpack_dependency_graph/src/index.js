import { sum, square } from './js/utils.js'
const getInfo = require('./js/api.js')

import './js/lg'

console.log(sum(10, 20))
console.log(square(10))
console.log(getInfo())

