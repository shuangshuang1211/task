import _ from 'lodash'
import $ from 'jquery'

console.log($)
console.log('main1.js文件')
console.log(_.join(['前端', '开发']))
