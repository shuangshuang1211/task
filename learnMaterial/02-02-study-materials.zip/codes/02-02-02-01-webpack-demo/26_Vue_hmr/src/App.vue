<template>
  <div class="example">{{ msg }}</div>
</template>

<script>
export default {
  data() {
    return {
      msg: 'Hello world!  222',
    }
  },
}
</script>

<style>
.example {
  color: orange;
}
</style>