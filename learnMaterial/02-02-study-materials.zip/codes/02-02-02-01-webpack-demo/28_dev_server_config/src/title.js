module.exports = 'aa'

console.log('title.js模块')