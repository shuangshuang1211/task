import 'lodash'
import './title'

console.log('index.js代码')