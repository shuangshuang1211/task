import { sum, square } from './js/utils.js'
const getInfo = require('./js/api.js')

import './js/login'

console.log(sum(10, 20))
console.log(square(10))
console.log(getInfo())


/**
 * 1 postcss 是什么： javascript 转换样式的工具
 * 2 less（less-loader） --> css --> css-loader
 * 3 postcss-preset-env 
 * 
 * 预设 -- 插件集合
 */
