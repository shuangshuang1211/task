const title = '前端'
const foo = () => {
  console.log(title)
}

foo()


/**
 * 01 为什么需要 Babel?
 *  JSX TS ES6+ ---> 浏览器平台直接使用
 *  转换
 *  postcss
 *  处理 JS 兼容
 *
 * @babel/plugin-transform-arrow-functions
 * @babel/plugin-transform-block-scoping 
 */