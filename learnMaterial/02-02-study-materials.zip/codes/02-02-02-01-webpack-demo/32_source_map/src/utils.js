const foo = () => {
  console.log('工具方法foo')
}

console.log(bb)

module.exports = foo
