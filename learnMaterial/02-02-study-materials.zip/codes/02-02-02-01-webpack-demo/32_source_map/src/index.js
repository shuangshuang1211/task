import title from './title'
import foo from './utils'

console.log('入口JS')
console.log(title)
foo()