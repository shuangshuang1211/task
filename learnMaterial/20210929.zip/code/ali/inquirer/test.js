const inquirer = require('inquirer')

//? 定义问题（按照它的格式定义）
const queList = [
  {
    type: 'checkbox',
    name: 'feature',
    pageSize: 2,
    message: '选择基础安装',
    choices: ['cba', 'nba', 'mba', 'abc', 'kobe', 'AI', 'tmc']
  }
]

//? 使用inquirer 来处理问题
inquirer.prompt(queList).then((an) => {
  console.log(an)
})
