const inquirer = require('inquirer')

//? 定义问题
let quesList = [
  {
    type: 'input',
    name: 'username',
    message: '用户名',
    validate(an) {
      if (!an) {
        return '当前为必填项'
      } else {
        return true
      }
    }
  }
]

//? 获取结果
inquirer.prompt(quesList).then((an) => {
  console.log(an.username)
})
/**
 * 基础字段
 * + type 定义问题类型
 * + name 将来问题的答案会被保存在一个对象当中，这里定义的值就是它的键名
 * + message 设置问题的提示信息
 * + default 设置默认值
 * + validate 函数，接收参数为当前问题的答案，可以添加判断的条件来决定后续走向
 */

