const inquirer = require('inquirer')

const quesList = [
  {
    type: 'confirm',
    name: 'isLoad',
    message: '是否执行下载'
  },
  {
    type: 'list',
    name: 'method',
    message: '选择下载方式',
    choices: ['npm', 'cnpm', 'yarn'],
    when(preAn) {
      return preAn.isLoad
    }
  }
]

inquirer.prompt(quesList).then((an) => {
  console.log(an)
})

/**
 * confirm 询问型问题，返回 true 或者 false
 * choices 接收一个数组，给问题提供选项
 * when 接收一个参数是一个问题的答案，可用于判断当前问题是否显示
 */