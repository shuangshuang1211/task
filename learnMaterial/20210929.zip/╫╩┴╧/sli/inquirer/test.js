const inquirer = require('inquirer')

// 准备问题
const quesList = [
  {
    type: 'checkbox',
    name: 'feature',
    message: '选择基础功能',
    pageSize: 2,
    choices: ['webpack', 'webpack-cli', 'eslint', 'jest', 'zoe', 'vueRouter', 'React']
  }
]

// 处理问题
inquirer.prompt(quesList).then((an) => {
  console.log(an.feature)
})

/**
 * 问题属性：
 *  + type：input list confirm checkbox
 *  + name: 用于做为答案的链出现
 *  + message: 用于问题的提示信息
 *  + choices: 出现选项时，设置为列表选项
 *  + pageSize: 设置每页显示的问题数量
 * 常见方法：
 *  + validate 校验
 *  + when 判断
 */