const chalk = require('chalk')

//? 文字颜色
console.log(chalk.green('绿色'))
console.log(chalk.keyword('red')('前端开发'))
console.log(chalk.hex('#fff')('前端开发'))

//? 背景颜色
console.log(chalk.bgGray('带背景'))

//? 格式化输出
console.log(chalk.green.bold`
  {red 从前慢}
  没有前端开发
`)

/**
 * 使用 chalk 包可以修改命令行终端字体的颜色
 * + 提供的关键字设置颜色：green red orange 等等
 * + 提供 keyword 方法接收键字
 * + 提供 hex 方法接收16进制
 * + 可以设置背景颜色
 * + 格式化输出文字内容
 */