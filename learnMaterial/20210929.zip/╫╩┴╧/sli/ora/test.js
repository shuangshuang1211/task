// import ora from 'ora'
const ora = require('ora')

const spinner = ora('正在下载......').start()
spinner.color = 'green'
// spinner.text = 'Loading rainbows'

setTimeout(() => {
  // spinner.succeed('下载成功')
  // spinner.fail('下载失败')
  spinner.info('下载内容')
}, 2000)

/**
 * 当前版本只支持 es6Module，可以将 package.json 文件中添加 type:module 字段
 * ora 实例化对象然后调用 start
 * color设置文字颜色
 * text 设置文字内容
 *
 * succeed 成功回调
 * fail 失败回调
 * info
 * ......
 */