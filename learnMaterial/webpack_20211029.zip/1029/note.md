## webpack 
1. 打包流程（ 分析源码来梳理主流程 ）
2. 理解打包器的核心原理（  ）
3. 能写loader( 原理 )
4. 能写plugin( 原理 )
5. hrm实现原理 tree shaking css-loader ast语法 babel详细

## 构建流程
> webpack 打包其实就是一个串行的过程，从启动到结束由多个具体的功能步骤组合实现
> 打包过程中，webpack 可以在特定的时间点去广播事件，然后使用插件来监听对应的事件是否被触发，从而执行回调

1. 初始化参数：从配置文件和shell语句当中读取并合并参数，从而得到最终的参数
2. 开始编译：用上一步得到的参数初始化一个 compiler 对象，加载所有配置插件，执行 run 方法来开启编译
3. 确定入口：依据配置当中的 entry 找到所有的入口文件 
4. 编译模块：从入口文件出发，调用所有配置当中的 loader 对模块进行翻译，再找出当前模块的依赖模块。（递归）
5. 完成编译：经过上一个步骤之后，得到了每个模块被翻译之后的内容，以及它们这间的关系，此时就可以输出资源
6. 输出资源：组装成一个个包含多个模块的 chunk ， 当我们有了 chunk之后还会在 JS 的数据结构上将他们放置于一个输出列表中
7. 输出完成：确定好输出内容之后，依据配置当中的路径和资源名称将它们写入到文件系统

## 证明run 就是入口
> 此时我们已经证明了 run 方法在 webpack 内部的确是一个入口 

## 分析去哪找 run 
1. npm run build `npx webpack`
2. 此时就相当于是在 node_module/.bin/webpack.cmd
3. 往后会找到 webpack/bin/webpack.js ，此时我们是安装了 webpack-cli 所以后续会执行 runCli 
4. 在 runCli 这个函数中最终执行的是 require(webpack-cli/bin/cli.js) ，此时就会去执行 cli.js 当中的代码
5. 在 cli.js 文件中又执行了 runCLI方法，在它内部执行了 new WebpackCli(),然后又调用了这个实例的 run 方法 
6. 进入 WebpackCli模块之后，发现他用到了 commander 这个包，依据我们的经验在这个包里会有一个 action()是用于监控命令行当中是否触发了某个命令（npm run build npx webpack）
7. 通过 program.action 找到了个回调函数，经过阅读我们发现，无论如何判断在这个回调函数当中核心就是执行 loadCommandByName方法
   
8. 在上述的方法当中有一个 makeCommand 方法，这个方法接收一个回调，在该回调中会执行 runWebpack ,在 runWebpack 当中会执行 createCompiler 方法 
   
9.  至此我们终于从命令执行 `npx webpack` 的操作一步一步的定位到了 webpack 源码的compiler 创建里 

```html

1. webpack 内部有一个钩子机制（发布订阅）

2. webpack打包是一个流程，插件机制很强大，在任意的地方可以去发布事件，然后在任意的地方去监听
如果某个事件（钩子）被触发了，那么它的回调就会执行

3. 经过源码分析我们可以发现，在 new Compiler 产生了 compiler 之后，就会将它传递给不同插件的 apply 方法，这样做的好就是我们可以有选择的在某些插件内部去发布或者去订阅某个钩子，这样一来
webpack 就活了【webpack 的插件机制很强大，但是它让 webpack 丧失了可阅读性】
```

