module.exports = function foo() {
  console.log('m模块当中的foo函数')
}

