const foo = require('./m')

console.log('index.js中的内容')
