export { reset as resetCounter } from "./counter";

export const print = value => console.log(value);
