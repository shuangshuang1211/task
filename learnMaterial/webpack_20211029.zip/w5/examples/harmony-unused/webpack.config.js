module.exports = {
	// mode: "development || "production",
	optimization: {
		concatenateModules: false
	}
};
