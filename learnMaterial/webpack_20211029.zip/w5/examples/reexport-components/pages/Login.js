import { Button, Dialog } from "../components";

const Login = () => {
	return (
		<>
			<Button />
			<Dialog />
		</>
	);
};
export default Login;
