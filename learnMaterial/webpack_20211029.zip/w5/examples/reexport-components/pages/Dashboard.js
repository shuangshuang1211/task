import { Button, Checkbox } from "../components";

const Dashboard = () => {
	return (
		<>
			<Button />
			<Checkbox />
		</>
	);
};
export default Dashboard;
