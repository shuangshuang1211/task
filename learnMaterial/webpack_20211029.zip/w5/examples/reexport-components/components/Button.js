const Button = () => {
	return <button />;
};
export { Button as default };
