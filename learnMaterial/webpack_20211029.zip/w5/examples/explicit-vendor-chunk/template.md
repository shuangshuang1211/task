# webpack.config.js

```javascript
_{{webpack.config.js}}_
```

# dist/vendor.js

```javascript
_{{dist/vendor.js}}_
```

# dist/pageA.js

```javascript
_{{dist/pageA.js}}_
```

# Info

## Unoptimized

```
_{{stdout}}_
```

## Production mode

```
_{{production:stdout}}_
```
