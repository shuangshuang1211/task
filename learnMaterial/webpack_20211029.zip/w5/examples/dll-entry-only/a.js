// module a
export var a = "a";
export * from "./b";
