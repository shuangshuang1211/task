const inc = require('./increment').increment;
const a = 1;
inc(a); // 2
