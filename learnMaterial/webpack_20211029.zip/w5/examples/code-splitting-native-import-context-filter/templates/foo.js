var foo = "foo";

export default foo;
