# example.js

```javascript
_{{example.js}}_
```

# dist/output.js

```javascript
_{{dist/output.js}}_
```

# dist/666.output.js

```javascript
_{{dist/666.output.js}}_
```

# dist/885.output.js

```javascript
_{{dist/885.output.js}}_
```

# Info

## Unoptimized

```
_{{stdout}}_
```

## Production mode

```
_{{production:stdout}}_
```
