//* 01 导入 webpack 函数
const webpack = require('../lib/webpack')

//* 02 加载配置信息
const config = require('./webpack.config')

//* 03 创建 compiler 对象
const compiler = webpack(config)

//* 04 调用run方法
compiler.run((err, stats) => {
  console.log(stats.toJson())
})