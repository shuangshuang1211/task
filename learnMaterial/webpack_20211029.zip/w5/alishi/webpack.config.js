const path = require('path')

module.exports = {
  mode: 'development',
  devtool: false,
  context: path.resolve(__dirname, '.'),
  entry: './src/index.js',
  output: {
    filename: 'build.js',
    path: path.resolve('dist')
  }
}