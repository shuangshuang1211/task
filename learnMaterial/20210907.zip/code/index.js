// let obj = {
/*   fn: function () {
    console.log(this, 111)
  }
}
let fn = obj.fn;
fn() // window
obj.fn();  // obj {fn:xxxx}

(10, fn, obj.fn)(); // window */

var a = 3, // 12 13
  obj = { a: 5 }  // 95
obj.fn = (function () {
  this.a *= ++a // window.a = window.a * (++a) 
  console.log(window.a, '<------') //! 12
  return function (b) {
    this.a *= (++a) + b  // obj.a = obj.a * ((++a)+b) -->95
    // window.a = window.a *((++a)+b)
    console.log(a)
  }
})();
var fn = obj.fn
obj.fn(6) // 将 Obj当中的a 修改为了 95，将全局的 a 修改了 13
fn(4) // 将全局的 a修改为了 234
console.log(obj.a, a)