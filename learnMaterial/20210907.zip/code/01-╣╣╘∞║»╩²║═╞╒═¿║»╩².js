function Foo(m, n) {
  let ret = m + n
  this.m = m
  this.n = n
  // this = 100
  // return this
  // return { x: 100, y: 200 }
}

// 01 普通函数调用
// let ret = Foo(10, 20)
// console.log(ret)

// 02 构造函数执行
// Foo 是函数么，肯定是？
// Foo 经过 new 之后它的执行又和普通函数有些不一样
// let res = new Foo(20, 20)
// console.log(res)  //? 输出的是什么  Foo {m: 20, n: 20}

let p1 = new Foo
let p2 = new Foo()

console.log(p1 === p2)

