<template>
  <div>
    <h1>About</h1>
  </div>
</template>

<script>
export default {
  name: 'AboutPage'
}
</script>

<style>

</style>
